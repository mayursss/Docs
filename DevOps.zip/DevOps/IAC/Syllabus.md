
Course Syllabus

The course structure is as follows:

-    Module 0: Course Introduction
        - Welcome
        - Course Overview
        - Labs Overview
        - Pre-Course Survey

-    Module 1: Azure Automation
Module 1 Learning Objectives
        - Infrastructure as Code and Automation
        - Automation Accounts
        - Automation Security
        - Runbook Assets
        - Runbook Basics
        - PowerShell Workflows
        - Labs
        - Module Review Questions
        - Module 1 Summary

-    Module 2: Desired State Configuration (DSC)
        - Module 2 Learning Objectives
        - DSC in DevOps
        - Automation DSC
        - Implementing Automation DSC
        Labs
        - Module Review Questions
        - Module 2 Summary

-   Module 3: Azure Resource Manager Templates
        - Module 3 Learning Objectives
        - Azure Resource Manager templates
        - Implementing Azure Resource Manager Templates
        - Azure Resource Manager templates and Visual Studio
        - Logging, Troubleshooting, and Diagnostics
        - Provisioning and Configuring Environments with Azure DevTest Labs
        Labs
        - Module Review Questions
        - MOdule 3 Summary

-    Module 4: Deploying and Managing Environments in Azur
        - Module 4 Learning Objectives
        - IaaS, PaaS, and Containers in Azure
        - Configuration Management
        - Chef, Puppet and Ansible in Azure
        - SaltStack in Azure
        - Cost Tracking and Optimization
        Labs
        - Module Review Questions
        - Module 4 Summary

-    Module 5: Final Exam

-    Module 6: Post-Course Survey